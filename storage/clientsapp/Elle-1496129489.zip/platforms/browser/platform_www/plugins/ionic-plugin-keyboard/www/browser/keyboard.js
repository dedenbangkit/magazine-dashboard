cordova.define("ionic-plugin-keyboard.keyboard", function(require, exports, module) { 
var argscheck = require('cordova/argscheck'),
    utils = require('cordova/utils'),
    exec = require('cordova/exec');


var Keyboard = function() {
};

Keyboard.hideKeyboardAccessoryBar = function(hide) {
    return null;
};

Keyboard.close = function() {
    return null;
};

Keyboard.show = function() {
    return null;
};

Keyboard.disableScroll = function(disable) {
    return null;
};

/*
Keyboard.styleDark = function(dark) {
 exec(null, null, "Keyboard", "styleDark", [dark]);
};
*/

Keyboard.isVisible = false;

module.exports = Keyboard;

});
